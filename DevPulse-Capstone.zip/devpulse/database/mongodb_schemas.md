# DevPulse — MongoDB Schema

MongoDB owns unstructured, high-volume, time-series data: raw commit telemetry, daily activity events, and AI analysis reports. MySQL owns identity (`user_id`, `project_id` are MySQL foreign keys referenced here as plain integers — no cross-database joins are enforced at the DB level; the Node.js API layer stitches them together).

## Collection: `commit_logs`

One document per commit ingested from the Git provider webhook / poller.

```js
{
  _id: ObjectId,
  userId: 2,                    // FK -> MySQL Users.id
  projectId: 1,                 // FK -> MySQL Projects.id
  repo: "example-org/devpulse-core",
  branch: "main",
  sha: "a1b2c3d4e5f6...",
  message: "fix: correct off-by-one in churn window",
  additions: 42,
  deletions: 17,
  filesChanged: 3,
  churnScore: 59,               // additions + deletions, precomputed for fast queries
  isMerge: false,
  authoredAt: ISODate("2026-08-20T09:14:00Z"),
  ingestedAt: ISODate("2026-08-20T09:15:02Z")
}
```

**Indexes:**
```js
db.commit_logs.createIndex({ userId: 1, authoredAt: -1 })
db.commit_logs.createIndex({ projectId: 1, authoredAt: -1 })
db.commit_logs.createIndex({ sha: 1 }, { unique: true })
```

## Collection: `daily_activity_events`

Raw focus-session and distraction telemetry from the client (e.g. a lightweight browser/editor tracker).

```js
{
  _id: ObjectId,
  userId: 2,
  type: "focus_session",        // "focus_session" | "distraction" | "break"
  startTime: ISODate("2026-08-20T10:00:00Z"),
  endTime: ISODate("2026-08-20T11:45:00Z"),
  durationMinutes: 105,
  context: {
    app: "VS Code",
    project: "devpulse-core"
  },
  metadata: {
    interruptionCount: 1
  },
  createdAt: ISODate("2026-08-20T11:45:03Z")
}
```

**Indexes:**
```js
db.daily_activity_events.createIndex({ userId: 1, startTime: -1 })
db.daily_activity_events.createIndex({ type: 1 })
```

## Collection: `ai_analysis_reports`

Output of the Python analytics service's AI code-review pass, one document per scan.

```js
{
  _id: ObjectId,
  userId: 2,
  projectId: 1,
  scope: "pull_request",        // "pull_request" | "commit" | "manual_snippet"
  refId: "PR-184",
  bugDensityScore: 0.34,        // 0 (clean) – 1 (high risk), heuristic + AI blended
  complexityFlags: [
    { file: "src/utils/churn.py", issue: "function exceeds 60 lines", severity: "medium" }
  ],
  refactorSuggestions: [
    "Extract the rolling-average calculation in computeChurn() into its own helper.",
    "Add a docstring to parse_commit_window() to clarify the expected date format."
  ],
  summary: "Moderate churn with one long function; no critical risk patterns detected.",
  generatedBy: "claude-sonnet-4-6",   // or "heuristic-fallback" when no API key is configured
  createdAt: ISODate("2026-08-20T12:02:00Z")
}
```

**Indexes:**
```js
db.ai_analysis_reports.createIndex({ userId: 1, createdAt: -1 })
db.ai_analysis_reports.createIndex({ projectId: 1, createdAt: -1 })
```

## Why this split (MySQL vs. MongoDB)

| Concern | Store | Reason |
|---|---|---|
| Users, Teams, Projects, Access_Tokens | MySQL | Strongly relational, low write volume, needs referential integrity and transactional guarantees (e.g. token rotation). |
| Commit telemetry, activity events, AI reports | MongoDB | High write volume, schema evolves per data source (different Git providers, different tracker clients), naturally document-shaped, queried mostly by time range rather than joins. |

The Node.js API gateway is the only service with credentials to both databases; the Python analytics service never touches either database directly — it receives JSON payloads from Node and returns computed results (see `../BLUEPRINT.md`).
