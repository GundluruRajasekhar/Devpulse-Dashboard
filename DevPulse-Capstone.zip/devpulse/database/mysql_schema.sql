-- ============================================================
-- DevPulse — MySQL schema
-- Owns: relational entities (Users, Teams, Projects, Access_Tokens)
-- ============================================================

CREATE DATABASE IF NOT EXISTS devpulse CHARACTER SET utf8mb4;
USE devpulse;

-- ---------------------------------------------------------------
-- Teams
-- ---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS Teams (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  name          VARCHAR(120) NOT NULL,
  slug          VARCHAR(140) NOT NULL UNIQUE,
  created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- ---------------------------------------------------------------
-- Users
-- ---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS Users (
  id                INT AUTO_INCREMENT PRIMARY KEY,
  team_id           INT NULL,
  name              VARCHAR(120) NOT NULL,
  email             VARCHAR(160) NOT NULL UNIQUE,
  password_hash     VARCHAR(255) NOT NULL,
  role              ENUM('admin','manager','developer') NOT NULL DEFAULT 'developer',
  github_username   VARCHAR(120) NULL,
  avatar_url        VARCHAR(255) NULL,
  is_active         BOOLEAN NOT NULL DEFAULT TRUE,
  created_at        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_users_team FOREIGN KEY (team_id) REFERENCES Teams(id) ON DELETE SET NULL
);

-- ---------------------------------------------------------------
-- Projects
-- ---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS Projects (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  team_id       INT NOT NULL,
  name          VARCHAR(140) NOT NULL,
  repo_url      VARCHAR(255) NOT NULL,
  default_branch VARCHAR(80) NOT NULL DEFAULT 'main',
  is_active     BOOLEAN NOT NULL DEFAULT TRUE,
  created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_projects_team FOREIGN KEY (team_id) REFERENCES Teams(id) ON DELETE CASCADE
);

-- ---------------------------------------------------------------
-- Access_Tokens  (encrypted provider tokens: GitHub, GitLab, etc.)
-- Never store raw tokens — token_encrypted holds ciphertext produced
-- by the backend's encryption utility (see src/utils/crypto.js).
-- ---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS Access_Tokens (
  id                INT AUTO_INCREMENT PRIMARY KEY,
  user_id           INT NOT NULL,
  provider          ENUM('github','gitlab','bitbucket') NOT NULL,
  token_encrypted   TEXT NOT NULL,
  scopes            VARCHAR(255) NULL,
  expires_at        DATETIME NULL,
  created_at        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_tokens_user FOREIGN KEY (user_id) REFERENCES Users(id) ON DELETE CASCADE,
  UNIQUE KEY uq_user_provider (user_id, provider)
);

-- ---------------------------------------------------------------
-- Project_Members  (many-to-many: which users belong to which projects)
-- ---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS Project_Members (
  project_id    INT NOT NULL,
  user_id       INT NOT NULL,
  joined_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (project_id, user_id),
  CONSTRAINT fk_pm_project FOREIGN KEY (project_id) REFERENCES Projects(id) ON DELETE CASCADE,
  CONSTRAINT fk_pm_user FOREIGN KEY (user_id) REFERENCES Users(id) ON DELETE CASCADE
);

-- ---------------------------------------------------------------
-- Seed data (safe, non-identifying demo data)
-- ---------------------------------------------------------------
INSERT INTO Teams (name, slug) VALUES
  ('Platform Engineering', 'platform-engineering'),
  ('Growth Squad', 'growth-squad')
ON DUPLICATE KEY UPDATE name = VALUES(name);

-- password_hash values below are bcrypt hashes of 'devpulse123' — demo only, rotate before real use
INSERT INTO Users (team_id, name, email, password_hash, role, github_username) VALUES
  (1, 'Asha Rao',    'asha@example.com',   '$2b$10$replaceWithRealBcryptHash1', 'manager',   'asha-rao'),
  (1, 'Kiran Mehta',  'kiran@example.com',  '$2b$10$replaceWithRealBcryptHash2', 'developer', 'kiran-m'),
  (2, 'Divya Nair',   'divya@example.com',  '$2b$10$replaceWithRealBcryptHash3', 'developer', 'divya-n')
ON DUPLICATE KEY UPDATE name = VALUES(name);

INSERT INTO Projects (team_id, name, repo_url, default_branch) VALUES
  (1, 'devpulse-core', 'https://github.com/example-org/devpulse-core', 'main'),
  (2, 'growth-experiments', 'https://github.com/example-org/growth-experiments', 'main')
ON DUPLICATE KEY UPDATE name = VALUES(name);
