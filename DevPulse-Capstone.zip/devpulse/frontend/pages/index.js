import Head from 'next/head';
import GitActivityWidget from '../components/GitActivityWidget';
import FocusTrackerWidget from '../components/FocusTrackerWidget';
import LeaderboardWidget from '../components/LeaderboardWidget';
import ProductivityInsightsWidget from '../components/ProductivityInsightsWidget';
import AICodeReviewWidget from '../components/AICodeReviewWidget';

export default function Dashboard() {
  return (
    <>
      <Head>
        <title>DevPulse — Developer Productivity Dashboard</title>
        <meta name="description" content="AI-enhanced developer productivity dashboard: git velocity, focus tracking, code review, and team leaderboards." />
      </Head>

      <div className="topbar">
        <div className="brand">
          <div className="brand-mark" />
          <div className="brand-name">DevPulse</div>
          <div className="brand-sub">Productivity Dashboard</div>
        </div>
        <div className="topbar-right">
          <div className="pill"><span className="dot" /> Live</div>
        </div>
      </div>

      <main className="shell">
        <div className="grid">
          <div className="col-8"><GitActivityWidget /></div>
          <div className="col-4"><FocusTrackerWidget /></div>

          <div className="col-6"><ProductivityInsightsWidget /></div>
          <div className="col-6"><LeaderboardWidget /></div>

          <div className="col-12"><AICodeReviewWidget /></div>
        </div>

        <div className="footnote">
          Data shown is served by the DevPulse API gateway when available, or realistic mock data otherwise — this dashboard is always browsable, even without a backend running.
        </div>
      </main>
    </>
  );
}
