import { useState } from 'react';
import { runCodeReview } from '../lib/api';

const SAMPLE = `def process(items):\n  # TODO handle empty list\n  try:\n    for i in items:\n      for j in items:\n        if i != j and i.id == j.id:\n          return True\n  except:\n    pass\n  return False\n`;

export default function AICodeReviewWidget() {
  const [code, setCode] = useState(SAMPLE);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);

  async function handleScan() {
    setLoading(true);
    const res = await runCodeReview({
      userId: 2,
      projectId: 1,
      scope: 'manual_snippet',
      refId: 'ad-hoc',
      snippets: [{ file: 'snippet.py', code }],
    });
    setResult(res);
    setLoading(false);
  }

  return (
    <div className="card">
      <div className="card-head">
        <div className="card-title">AI Code Review</div>
        <div className="card-sub">bug density · refactor tips</div>
      </div>
      <textarea className="code-input" value={code} onChange={e => setCode(e.target.value)} spellCheck={false} />
      <div style={{ marginTop: 10, display: 'flex', gap: 10, alignItems: 'center' }}>
        <button className="btn btn-primary" onClick={handleScan} disabled={loading}>
          {loading ? 'Scanning…' : 'Scan snippet'}
        </button>
        {result && <span className="card-sub">via {result.generatedBy}</span>}
      </div>

      {result && (
        <div style={{ marginTop: 14 }}>
          <div className="stat-row">
            <div className="stat">
              <div className="stat-num" style={{ color: result.bugDensityScore > 0.5 ? 'var(--red)' : result.bugDensityScore > 0.2 ? 'var(--amber)' : 'var(--lime)' }}>
                {result.bugDensityScore}
              </div>
              <div className="stat-label">Bug density</div>
            </div>
          </div>
          {result.complexityFlags.map((f, i) => (
            <div className="insight" key={i}>
              <div className="insight-head">
                <span className="insight-label">{f.file}</span>
                <span className={`badge ${f.severity === 'high' ? 'badge-warning' : 'badge-info'}`}>{f.severity}</span>
              </div>
              <div className="insight-detail">{f.issue}</div>
            </div>
          ))}
          <div className="card-sub" style={{ margin: '10px 0 4px' }}>Refactor suggestions</div>
          {result.refactorSuggestions.length === 0 && <p style={{ fontSize: 12, color: 'var(--text-faint)' }}>None — snippet looks clean.</p>}
          {result.refactorSuggestions.map((s, i) => <div className="suggestion" key={i}>{s}</div>)}
          <div className="insight-detail" style={{ marginTop: 8 }}>{result.summary}</div>
        </div>
      )}
    </div>
  );
}
