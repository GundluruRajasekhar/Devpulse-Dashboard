import { useEffect, useState } from 'react';
import { getFocusSummary } from '../lib/api';

const COLORS = { focus_session: 'var(--lime)', distraction: 'var(--red)', break: 'var(--blue)' };
const LABELS = { focus_session: 'Deep focus', distraction: 'Distraction', break: 'Break' };

export default function FocusTrackerWidget() {
  const [data, setData] = useState(null);

  useEffect(() => {
    getFocusSummary(null, 7).then(setData);
  }, []);

  if (!data) return <Card title="Focus Tracker" sub="last 7 days"><p style={{ color: 'var(--text-faint)', fontSize: 12 }}>Loading…</p></Card>;

  const entries = Object.entries(data.summary);
  const total = entries.reduce((a, [, v]) => a + v.totalMinutes, 0) || 1;
  let cumulative = 0;
  const circumference = 2 * Math.PI * 15.9155;

  return (
    <Card title="Focus Tracker" sub={`last ${data.days} days`}>
      <div className="focus-ring-wrap">
        <svg width="90" height="90" viewBox="0 0 42 42">
          {entries.map(([key, v]) => {
            const frac = v.totalMinutes / total;
            const dash = frac * circumference;
            const el = (
              <circle
                key={key}
                cx="21" cy="21" r="15.9155" fill="none"
                stroke={COLORS[key]} strokeWidth="5"
                strokeDasharray={`${dash} ${circumference - dash}`}
                strokeDashoffset={-cumulative}
              />
            );
            cumulative += dash;
            return el;
          })}
          <text x="21" y="24" textAnchor="middle" fontSize="8" fill="var(--text)" fontFamily="var(--font-mono)">{data.focusScore}</text>
        </svg>
        <div className="focus-legend">
          {entries.map(([key, v]) => (
            <div key={key}>
              <span className="swatch" style={{ background: COLORS[key] }} />
              {LABELS[key]} — {Math.round(v.totalMinutes / 60)}h
            </div>
          ))}
        </div>
      </div>
      <div style={{ marginTop: 10, fontSize: 12, color: 'var(--text-dim)' }}>
        Focus score <b style={{ color: 'var(--lime)' }}>{data.focusScore}/100</b> — share of tracked time spent in uninterrupted deep-work sessions.
      </div>
    </Card>
  );
}

function Card({ title, sub, children }) {
  return (
    <div className="card">
      <div className="card-head">
        <div className="card-title">{title}</div>
        <div className="card-sub">{sub}</div>
      </div>
      {children}
    </div>
  );
}
