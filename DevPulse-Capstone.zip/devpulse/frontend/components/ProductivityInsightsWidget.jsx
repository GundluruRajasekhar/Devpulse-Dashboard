import { useEffect, useState } from 'react';
import { getProductivityInsights } from '../lib/api';

const SEVERITY_BADGE = { positive: 'badge-positive', warning: 'badge-warning', info: 'badge-info' };

export default function ProductivityInsightsWidget() {
  const [data, setData] = useState(null);

  useEffect(() => {
    getProductivityInsights(null, 14).then(setData);
  }, []);

  if (!data) return <Card title="AI Productivity Insights" sub="Python analytics engine"><p style={{ color: 'var(--text-faint)', fontSize: 12 }}>Loading…</p></Card>;

  return (
    <Card title="AI Productivity Insights" sub="Python analytics engine">
      <div className="stat-row">
        <div className="stat"><div className="stat-num">{data.commitCount}</div><div className="stat-label">Commits</div></div>
        <div className="stat"><div className="stat-num">{data.consistencyScore}</div><div className="stat-label">Consistency</div></div>
        <div className="stat"><div className="stat-num" style={{ textTransform: 'capitalize' }}>{data.velocityTrend.replace('_', ' ')}</div><div className="stat-label">Velocity trend</div></div>
      </div>
      <div style={{ marginTop: 8 }}>
        {data.insights.length === 0 && <p style={{ fontSize: 12, color: 'var(--text-faint)' }}>No notable patterns this window.</p>}
        {data.insights.map((ins, i) => (
          <div className="insight" key={i}>
            <div className="insight-head">
              <span className="insight-label">{ins.label}</span>
              <span className={`badge ${SEVERITY_BADGE[ins.severity] || 'badge-info'}`}>{ins.severity}</span>
            </div>
            <div className="insight-detail">{ins.detail}</div>
          </div>
        ))}
      </div>
    </Card>
  );
}

function Card({ title, sub, children }) {
  return (
    <div className="card">
      <div className="card-head">
        <div className="card-title">{title}</div>
        <div className="card-sub">{sub}</div>
      </div>
      {children}
    </div>
  );
}
