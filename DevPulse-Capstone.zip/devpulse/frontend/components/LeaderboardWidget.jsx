import { useEffect, useState } from 'react';
import { getLeaderboard } from '../lib/api';

export default function LeaderboardWidget() {
  const [data, setData] = useState(null);

  useEffect(() => {
    getLeaderboard(14).then(setData);
  }, []);

  if (!data) return <Card title="Team Leaderboard" sub="last 14 days"><p style={{ color: 'var(--text-faint)', fontSize: 12 }}>Loading…</p></Card>;

  return (
    <Card title="Team Leaderboard" sub={data.anonymized ? 'anonymized · sprint velocity' : `last ${data.days} days`}>
      {data.leaderboard.map(row => (
        <div className="leader-row" key={row.rank}>
          <div className="leader-rank">#{row.rank}</div>
          <div className="leader-name">{row.label}</div>
          <div className="leader-metric">{row.commits} commits · {row.churn} churn</div>
        </div>
      ))}
      {data.anonymized && (
        <div style={{ marginTop: 10, fontSize: 11, color: 'var(--text-faint)' }}>
          Names are hidden from this view — only managers/admins see identified rankings.
        </div>
      )}
    </Card>
  );
}

function Card({ title, sub, children }) {
  return (
    <div className="card">
      <div className="card-head">
        <div className="card-title">{title}</div>
        <div className="card-sub">{sub}</div>
      </div>
      {children}
    </div>
  );
}
