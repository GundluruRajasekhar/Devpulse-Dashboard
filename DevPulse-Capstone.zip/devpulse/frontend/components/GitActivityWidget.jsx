import { useEffect, useState } from 'react';
import { getGitActivity } from '../lib/api';

export default function GitActivityWidget() {
  const [data, setData] = useState(null);

  useEffect(() => {
    getGitActivity(null, 14).then(setData);
  }, []);

  if (!data) return <Card title="Git Activity" sub="last 14 days"><p style={{ color: 'var(--text-faint)', fontSize: 12 }}>Loading…</p></Card>;

  const max = Math.max(1, ...data.series.map(d => d.commits));
  const totalCommits = data.series.reduce((a, d) => a + d.commits, 0);
  const totalChurn = data.series.reduce((a, d) => a + d.churn, 0);

  return (
    <Card title="Git Activity" sub={`last ${data.days} days`}>
      <div className="stat-row">
        <div className="stat"><div className="stat-num">{totalCommits}</div><div className="stat-label">Commits</div></div>
        <div className="stat"><div className="stat-num">{totalChurn}</div><div className="stat-label">Total churn</div></div>
      </div>
      <svg width="100%" height="90" viewBox={`0 0 ${data.series.length * 22} 90`} preserveAspectRatio="none" style={{ marginTop: 10 }}>
        {data.series.map((d, i) => {
          const h = Math.max(3, (d.commits / max) * 74);
          return (
            <rect
              key={d._id}
              x={i * 22 + 4}
              y={82 - h}
              width={14}
              height={h}
              rx={3}
              fill={d.commits >= max * 0.75 ? 'var(--lime)' : 'var(--blue)'}
              opacity={0.9}
            />
          );
        })}
      </svg>
      <div style={{ display: 'flex', justifyContent: 'space-between', fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--text-faint)' }}>
        <span>{data.series[0]?._id}</span>
        <span>{data.series[data.series.length - 1]?._id}</span>
      </div>
    </Card>
  );
}

function Card({ title, sub, children }) {
  return (
    <div className="card">
      <div className="card-head">
        <div className="card-title">{title}</div>
        <div className="card-sub">{sub}</div>
      </div>
      {children}
    </div>
  );
}
