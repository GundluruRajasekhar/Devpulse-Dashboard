from dotenv import load_dotenv
load_dotenv()

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.routers import insights, code_review

app = FastAPI(title="DevPulse Analytics Service", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # the Node.js gateway is the only intended caller; tighten in production
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(insights.router)
app.include_router(code_review.router)


@app.get("/health")
def health():
    return {"status": "ok", "service": "devpulse-analytics"}
