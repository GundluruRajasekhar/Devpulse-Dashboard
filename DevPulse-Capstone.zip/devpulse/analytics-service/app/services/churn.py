"""
Churn & velocity analysis using pandas.
Given a flat list of commit points, compute daily churn, active-day count,
a naive trend classification, and a 'consistency score' rewarding steady
daily contribution over bursty all-nighters (a proxy for sustainable pace).
"""
import pandas as pd


def analyze_commits(commits: list[dict], window_days: int) -> dict:
    if not commits:
        return {
            "velocityTrend": "insufficient_data",
            "avgDailyChurn": 0.0,
            "commitCount": 0,
            "activeDays": 0,
            "consistencyScore": 0,
            "daily": [],
        }

    df = pd.DataFrame(commits)
    df["authoredAt"] = pd.to_datetime(df["authoredAt"])
    df["date"] = df["authoredAt"].dt.date

    daily = df.groupby("date").agg(
        commits=("churnScore", "count"),
        churn=("churnScore", "sum"),
    ).reset_index().sort_values("date")

    active_days = len(daily)
    avg_daily_churn = round(float(daily["churn"].mean()), 2) if active_days else 0.0

    # Trend: compare mean churn of the first half of the window vs. the second half
    if active_days >= 4:
        midpoint = active_days // 2
        first_half_mean = daily["churn"].iloc[:midpoint].mean()
        second_half_mean = daily["churn"].iloc[midpoint:].mean()
        if second_half_mean > first_half_mean * 1.15:
            trend = "rising"
        elif second_half_mean < first_half_mean * 0.85:
            trend = "falling"
        else:
            trend = "stable"
    else:
        trend = "insufficient_data"

    # Consistency: active days as a fraction of the window, penalized by high variance
    coverage = min(1.0, active_days / max(1, window_days))
    variance_penalty = 0.0
    if active_days > 1 and daily["commits"].mean() > 0:
        cv = daily["commits"].std() / daily["commits"].mean()  # coefficient of variation
        variance_penalty = min(0.5, cv * 0.2)
    consistency_score = round(max(0.0, coverage - variance_penalty) * 100)

    return {
        "velocityTrend": trend,
        "avgDailyChurn": avg_daily_churn,
        "commitCount": int(df.shape[0]),
        "activeDays": int(active_days),
        "consistencyScore": int(consistency_score),
        "daily": [
            {"date": str(row["date"]), "commits": int(row["commits"]), "churn": int(row["churn"])}
            for _, row in daily.iterrows()
        ],
    }


def build_insights(stats: dict) -> list[dict]:
    insights = []

    if stats["velocityTrend"] == "rising":
        insights.append({
            "label": "Velocity climbing",
            "detail": f"Daily churn trending upward across the window (avg {stats['avgDailyChurn']} lines/day).",
            "severity": "positive",
        })
    elif stats["velocityTrend"] == "falling":
        insights.append({
            "label": "Velocity slowing",
            "detail": "Commit churn has dropped in the second half of the window — worth checking in on blockers.",
            "severity": "warning",
        })
    elif stats["velocityTrend"] == "insufficient_data":
        insights.append({
            "label": "Not enough data yet",
            "detail": "Fewer than 4 active days in this window — trend detection needs more history.",
            "severity": "info",
        })

    if stats["consistencyScore"] >= 70:
        insights.append({
            "label": "Steady, sustainable pace",
            "detail": f"Consistency score {stats['consistencyScore']}/100 — contributions are evenly spread, not bursty.",
            "severity": "positive",
        })
    elif stats["consistencyScore"] < 35 and stats["commitCount"] > 0:
        insights.append({
            "label": "Bursty contribution pattern",
            "detail": f"Consistency score {stats['consistencyScore']}/100 — activity is concentrated in a few days, a common precursor to burnout.",
            "severity": "warning",
        })

    return insights
