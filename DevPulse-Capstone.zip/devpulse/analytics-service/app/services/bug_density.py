"""
Heuristic static-analysis pass used both as a standalone signal and as the
fallback when no AI key is configured. Deliberately simple and dependency-free
(no external linters) so it always runs, deterministically, in milliseconds.
"""
import re


LONG_FUNCTION_LINES = 40
TODO_PATTERN = re.compile(r"\b(TODO|FIXME|HACK)\b", re.IGNORECASE)
NESTED_LOOP_PATTERN = re.compile(r"for\s*\(.*\)\s*\{[^}]*for\s*\(", re.DOTALL)
BARE_EXCEPT_PATTERN = re.compile(r"except\s*:\s*\n")


def scan_snippet(file: str, code: str) -> dict:
    flags = []
    lines = code.splitlines()

    # crude function-length check (works reasonably for C-like and Python bodies)
    func_starts = [i for i, l in enumerate(lines) if re.match(r"^\s*(def |function |const .*=.*\(.*\)\s*=>|.*\)\s*\{)", l)]
    for start in func_starts:
        # look ahead for the next blank-indent boundary as a rough function end
        depth_window = lines[start:start + LONG_FUNCTION_LINES + 5]
        if len(depth_window) > LONG_FUNCTION_LINES:
            flags.append({"file": file, "issue": f"function starting near line {start+1} exceeds {LONG_FUNCTION_LINES} lines", "severity": "medium"})
            break  # one flag per snippet keeps output readable

    todo_count = len(TODO_PATTERN.findall(code))
    if todo_count > 0:
        flags.append({"file": file, "issue": f"{todo_count} TODO/FIXME marker(s) left in code", "severity": "low"})

    if NESTED_LOOP_PATTERN.search(code):
        flags.append({"file": file, "issue": "nested loop detected — check for O(n^2) risk on large inputs", "severity": "medium"})

    if BARE_EXCEPT_PATTERN.search(code):
        flags.append({"file": file, "issue": "bare except clause swallows all errors", "severity": "high"})

    # crude bug-density proxy: weighted flag count normalized by lines of code
    weights = {"low": 1, "medium": 2, "high": 3}
    raw_score = sum(weights.get(f["severity"], 1) for f in flags)
    loc = max(1, len(lines))
    density = min(1.0, round(raw_score / (loc / 20), 3))  # normalize per ~20 lines

    return {"flags": flags, "density": density}


def scan_all(snippets: list[dict]) -> dict:
    all_flags = []
    densities = []
    for s in snippets:
        result = scan_snippet(s["file"], s["code"])
        all_flags.extend(result["flags"])
        densities.append(result["density"])

    overall_density = round(sum(densities) / len(densities), 3) if densities else 0.0
    return {"complexityFlags": all_flags, "bugDensityScore": overall_density}
