"""
Optional AI layer: if ANTHROPIC_API_KEY is configured, ask Claude for
refactor suggestions and a narrative summary grounded in the heuristic scan
results. If the key is missing or the call fails for any reason, fall back
to a deterministic, rule-derived summary — this service must never 500 just
because the AI layer is unavailable.
"""
import os
import json
import requests

ANTHROPIC_URL = "https://api.anthropic.com/v1/messages"


def _fallback_summary(flags: list[dict], density: float) -> dict:
    if not flags:
        return {
            "refactorSuggestions": [],
            "summary": "No structural issues detected by the heuristic scan.",
            "generatedBy": "heuristic-fallback",
        }
    suggestions = []
    for f in flags[:5]:
        if "exceeds" in f["issue"]:
            suggestions.append(f"Consider splitting the long function in {f['file']} into smaller, named helpers.")
        elif "nested loop" in f["issue"]:
            suggestions.append(f"Review the nested loop in {f['file']} for a possible O(n) alternative (e.g. a hash map lookup).")
        elif "bare except" in f["issue"]:
            suggestions.append(f"Replace the bare except in {f['file']} with a specific exception type.")
        elif "TODO" in f["issue"]:
            suggestions.append(f"Resolve or ticket the outstanding TODO/FIXME markers in {f['file']}.")
    return {
        "refactorSuggestions": suggestions,
        "summary": f"Heuristic scan found {len(flags)} issue(s) across the submitted snippets; bug-density score {density}.",
        "generatedBy": "heuristic-fallback",
    }


def generate_ai_review(flags: list[dict], density: float, snippets: list[dict]) -> dict:
    api_key = os.getenv("ANTHROPIC_API_KEY", "").strip()
    if not api_key:
        return _fallback_summary(flags, density)

    model = os.getenv("ANTHROPIC_MODEL", "claude-sonnet-4-6")
    snippet_preview = "\n\n".join(
        f"--- {s['file']} ---\n{s['code'][:1200]}" for s in snippets[:4]
    )
    system_prompt = (
        "You are a senior code reviewer inside DevPulse, a developer productivity dashboard. "
        "You are given heuristic static-analysis flags and the raw code snippets they came from. "
        "Respond ONLY with minified JSON, no markdown fences, matching exactly: "
        '{"refactorSuggestions": ["...", "..."], "summary": "2-3 sentence plain-English summary for the developer"}. '
        "Ground every suggestion in something specific from the code — file names, function names, or line-level detail. "
        "Keep the list to at most 5 suggestions."
    )
    user_payload = {
        "heuristicFlags": flags,
        "bugDensityScore": density,
        "codeSnippets": snippet_preview,
    }

    try:
        resp = requests.post(
            ANTHROPIC_URL,
            headers={
                "Content-Type": "application/json",
                "x-api-key": api_key,
                "anthropic-version": "2023-06-01",
            },
            json={
                "model": model,
                "max_tokens": 700,
                "system": system_prompt,
                "messages": [{"role": "user", "content": json.dumps(user_payload)}],
            },
            timeout=20,
        )
        resp.raise_for_status()
        data = resp.json()
        text_block = next((b for b in data.get("content", []) if b.get("type") == "text"), None)
        if not text_block:
            raise ValueError("no text block in Anthropic response")
        cleaned = text_block["text"].strip()
        cleaned = cleaned.removeprefix("```json").removeprefix("```").removesuffix("```").strip()
        parsed = json.loads(cleaned)
        return {
            "refactorSuggestions": parsed.get("refactorSuggestions", []),
            "summary": parsed.get("summary", ""),
            "generatedBy": model,
        }
    except Exception as exc:  # network error, bad JSON, rate limit, etc.
        fallback = _fallback_summary(flags, density)
        fallback["summary"] = f"[AI layer unavailable: {exc.__class__.__name__}] " + fallback["summary"]
        return fallback
