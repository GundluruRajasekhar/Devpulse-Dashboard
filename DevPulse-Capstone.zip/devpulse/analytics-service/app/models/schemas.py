from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime


class CommitPoint(BaseModel):
    authoredAt: datetime
    additions: int = 0
    deletions: int = 0
    churnScore: int = 0
    isMerge: bool = False


class ProductivityRequest(BaseModel):
    userId: Optional[int] = None
    windowDays: int = 14
    commits: List[CommitPoint] = []


class ProductivityInsight(BaseModel):
    label: str
    detail: str
    severity: str  # "info" | "positive" | "warning"


class ProductivityResponse(BaseModel):
    velocityTrend: str          # "rising" | "falling" | "stable" | "insufficient_data"
    avgDailyChurn: float
    commitCount: int
    activeDays: int
    consistencyScore: int       # 0-100, how evenly distributed commits are across the window
    insights: List[ProductivityInsight]


class CodeSnippet(BaseModel):
    file: str
    code: str


class CodeReviewRequest(BaseModel):
    snippets: List[CodeSnippet]
    useAi: bool = True


class ComplexityFlag(BaseModel):
    file: str
    issue: str
    severity: str


class CodeReviewResponse(BaseModel):
    bugDensityScore: float
    complexityFlags: List[ComplexityFlag]
    refactorSuggestions: List[str]
    summary: str
    generatedBy: str
