from fastapi import APIRouter
from app.models.schemas import CodeReviewRequest, CodeReviewResponse
from app.services.bug_density import scan_all
from app.services.ai_insights import generate_ai_review

router = APIRouter(prefix="/code-review", tags=["code-review"])


@router.post("/scan", response_model=CodeReviewResponse)
def scan(payload: CodeReviewRequest):
    snippets = [s.model_dump() for s in payload.snippets]
    heuristic = scan_all(snippets)

    if payload.useAi:
        ai_result = generate_ai_review(heuristic["complexityFlags"], heuristic["bugDensityScore"], snippets)
    else:
        ai_result = {"refactorSuggestions": [], "summary": "AI review skipped by request.", "generatedBy": "heuristic-fallback"}

    return CodeReviewResponse(
        bugDensityScore=heuristic["bugDensityScore"],
        complexityFlags=heuristic["complexityFlags"],
        refactorSuggestions=ai_result["refactorSuggestions"],
        summary=ai_result["summary"],
        generatedBy=ai_result["generatedBy"],
    )
