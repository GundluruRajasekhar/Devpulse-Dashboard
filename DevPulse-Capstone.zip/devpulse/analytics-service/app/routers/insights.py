from fastapi import APIRouter
from app.models.schemas import ProductivityRequest, ProductivityResponse
from app.services.churn import analyze_commits, build_insights

router = APIRouter(prefix="/insights", tags=["insights"])


@router.post("/productivity", response_model=ProductivityResponse)
def productivity_insights(payload: ProductivityRequest):
    commits = [c.model_dump() for c in payload.commits]
    stats = analyze_commits(commits, payload.windowDays)
    insights = build_insights(stats)
    return ProductivityResponse(
        velocityTrend=stats["velocityTrend"],
        avgDailyChurn=stats["avgDailyChurn"],
        commitCount=stats["commitCount"],
        activeDays=stats["activeDays"],
        consistencyScore=stats["consistencyScore"],
        insights=insights,
    )
