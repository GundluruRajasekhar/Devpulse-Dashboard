require('dotenv').config();
const express = require('express');
const cors = require('cors');
const morgan = require('morgan');

const { connectMySQL } = require('./src/config/db.mysql');
const { connectMongo } = require('./src/config/db.mongo');

const authRoutes = require('./src/routes/auth');
const gitRoutes = require('./src/routes/git');
const focusRoutes = require('./src/routes/focus');
const leaderboardRoutes = require('./src/routes/leaderboard');
const analyticsRoutes = require('./src/routes/analytics');

const app = express();

app.use(cors({ origin: process.env.FRONTEND_ORIGIN || 'http://localhost:3000' }));
app.use(express.json({ limit: '2mb' }));
app.use(morgan('dev'));

app.get('/api/health', (req, res) => res.json({ status: 'ok', service: 'devpulse-backend', time: new Date().toISOString() }));

app.use('/api/auth', authRoutes);
app.use('/api/git', gitRoutes);
app.use('/api/focus', focusRoutes);
app.use('/api/leaderboard', leaderboardRoutes);
app.use('/api/analytics', analyticsRoutes);

app.use((req, res) => res.status(404).json({ error: 'Not found' }));
app.use((err, req, res, next) => {
  console.error('[unhandled]', err);
  res.status(500).json({ error: 'Internal server error' });
});

const PORT = process.env.PORT || 4000;

(async () => {
  await connectMySQL();
  await connectMongo();
  app.listen(PORT, () => console.log(`[devpulse-backend] listening on :${PORT}`));
})();
