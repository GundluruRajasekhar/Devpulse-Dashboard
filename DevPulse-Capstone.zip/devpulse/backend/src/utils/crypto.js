// Symmetric encryption helper for storing provider tokens (Access_Tokens.token_encrypted).
// Uses AES-256-GCM with a key from TOKEN_ENCRYPTION_KEY (must be 32 bytes).
const crypto = require('crypto');

const ALGO = 'aes-256-gcm';

function getKey() {
  const raw = process.env.TOKEN_ENCRYPTION_KEY || '';
  return crypto.createHash('sha256').update(raw).digest(); // normalize to 32 bytes
}

function encryptToken(plainText) {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv(ALGO, getKey(), iv);
  const encrypted = Buffer.concat([cipher.update(plainText, 'utf8'), cipher.final()]);
  const authTag = cipher.getAuthTag();
  return Buffer.concat([iv, authTag, encrypted]).toString('base64');
}

function decryptToken(payloadBase64) {
  const raw = Buffer.from(payloadBase64, 'base64');
  const iv = raw.subarray(0, 12);
  const authTag = raw.subarray(12, 28);
  const encrypted = raw.subarray(28);
  const decipher = crypto.createDecipheriv(ALGO, getKey(), iv);
  decipher.setAuthTag(authTag);
  return Buffer.concat([decipher.update(encrypted), decipher.final()]).toString('utf8');
}

module.exports = { encryptToken, decryptToken };
