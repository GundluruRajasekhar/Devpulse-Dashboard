const mongoose = require('mongoose');

const AiAnalysisReportSchema = new mongoose.Schema({
  userId: { type: Number, required: true, index: true },
  projectId: { type: Number, required: true, index: true },
  scope: { type: String, enum: ['pull_request', 'commit', 'manual_snippet'], required: true },
  refId: { type: String },
  bugDensityScore: { type: Number, default: 0 },
  complexityFlags: [{ file: String, issue: String, severity: String }],
  refactorSuggestions: [String],
  summary: { type: String },
  generatedBy: { type: String, default: 'heuristic-fallback' },
  createdAt: { type: Date, default: Date.now },
});

module.exports = mongoose.models.AiAnalysisReport || mongoose.model('AiAnalysisReport', AiAnalysisReportSchema, 'ai_analysis_reports');
