const mongoose = require('mongoose');

const DailyActivityEventSchema = new mongoose.Schema({
  userId: { type: Number, required: true, index: true },
  type: { type: String, enum: ['focus_session', 'distraction', 'break'], required: true },
  startTime: { type: Date, required: true, index: true },
  endTime: { type: Date },
  durationMinutes: { type: Number, default: 0 },
  context: {
    app: String,
    project: String,
  },
  metadata: { type: mongoose.Schema.Types.Mixed, default: {} },
  createdAt: { type: Date, default: Date.now },
});

module.exports = mongoose.models.DailyActivityEvent || mongoose.model('DailyActivityEvent', DailyActivityEventSchema, 'daily_activity_events');
