const mongoose = require('mongoose');

const CommitLogSchema = new mongoose.Schema({
  userId: { type: Number, required: true, index: true },
  projectId: { type: Number, required: true, index: true },
  repo: { type: String, required: true },
  branch: { type: String, default: 'main' },
  sha: { type: String, required: true, unique: true },
  message: { type: String, default: '' },
  additions: { type: Number, default: 0 },
  deletions: { type: Number, default: 0 },
  filesChanged: { type: Number, default: 0 },
  churnScore: { type: Number, default: 0 },
  isMerge: { type: Boolean, default: false },
  authoredAt: { type: Date, required: true, index: true },
  ingestedAt: { type: Date, default: Date.now },
});

module.exports = mongoose.models.CommitLog || mongoose.model('CommitLog', CommitLogSchema, 'commit_logs');
