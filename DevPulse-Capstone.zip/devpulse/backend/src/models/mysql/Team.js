const { DataTypes } = require('sequelize');
const { sequelize } = require('../../config/db.mysql');

const Team = sequelize.define('Team', {
  id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  name: { type: DataTypes.STRING(120), allowNull: false },
  slug: { type: DataTypes.STRING(140), allowNull: false, unique: true },
}, {
  tableName: 'Teams',
  timestamps: true,
  createdAt: 'created_at',
  updatedAt: false,
});

module.exports = Team;
