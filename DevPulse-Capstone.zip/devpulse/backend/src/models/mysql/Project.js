const { DataTypes } = require('sequelize');
const { sequelize } = require('../../config/db.mysql');

const Project = sequelize.define('Project', {
  id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  team_id: { type: DataTypes.INTEGER, allowNull: false },
  name: { type: DataTypes.STRING(140), allowNull: false },
  repo_url: { type: DataTypes.STRING(255), allowNull: false },
  default_branch: { type: DataTypes.STRING(80), defaultValue: 'main' },
  is_active: { type: DataTypes.BOOLEAN, defaultValue: true },
}, {
  tableName: 'Projects',
  timestamps: true,
  createdAt: 'created_at',
  updatedAt: false,
});

module.exports = Project;
