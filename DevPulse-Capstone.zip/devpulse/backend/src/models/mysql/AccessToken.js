const { DataTypes } = require('sequelize');
const { sequelize } = require('../../config/db.mysql');

const AccessToken = sequelize.define('AccessToken', {
  id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  user_id: { type: DataTypes.INTEGER, allowNull: false },
  provider: { type: DataTypes.ENUM('github', 'gitlab', 'bitbucket'), allowNull: false },
  token_encrypted: { type: DataTypes.TEXT, allowNull: false },
  scopes: { type: DataTypes.STRING(255), allowNull: true },
  expires_at: { type: DataTypes.DATE, allowNull: true },
}, {
  tableName: 'Access_Tokens',
  timestamps: true,
  createdAt: 'created_at',
  updatedAt: false,
});

module.exports = AccessToken;
