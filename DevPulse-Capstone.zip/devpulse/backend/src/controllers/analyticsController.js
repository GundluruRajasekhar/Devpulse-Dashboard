const axios = require('axios');
const CommitLog = require('../models/mongo/CommitLog');
const AiAnalysisReport = require('../models/mongo/AiAnalysisReport');

const ANALYTICS_URL = process.env.ANALYTICS_SERVICE_URL || 'http://localhost:8000';

// GET /api/analytics/productivity?userId=2&days=14
// Node fetches raw commit + churn data from Mongo, then POSTs it to the Python
// service for computation. Node owns all DB access; Python is a stateless compute layer.
async function getProductivityInsights(req, res) {
  try {
    const { userId, days = 14 } = req.query;
    const since = new Date(Date.now() - Number(days) * 24 * 60 * 60 * 1000);
    const match = { authoredAt: { $gte: since } };
    if (userId) match.userId = Number(userId);

    const commits = await CommitLog.find(match).sort({ authoredAt: 1 }).lean();

    const { data } = await axios.post(`${ANALYTICS_URL}/insights/productivity`, {
      userId: userId ? Number(userId) : null,
      windowDays: Number(days),
      commits: commits.map(c => ({
        authoredAt: c.authoredAt,
        additions: c.additions,
        deletions: c.deletions,
        churnScore: c.churnScore,
        isMerge: c.isMerge,
      })),
    }, { timeout: 8000 });

    res.json(data);
  } catch (err) {
    console.error('[analytics.getProductivityInsights]', err.message);
    // Graceful degradation: analytics service down should not break the dashboard
    res.status(200).json({
      degraded: true,
      message: 'Analytics engine unavailable — showing no insights this session.',
      velocityTrend: 'unknown',
      insights: [],
    });
  }
}

// POST /api/analytics/code-review  { userId, projectId, scope, refId, snippets: [{file, code}] }
async function runCodeReview(req, res) {
  try {
    const { userId, projectId, scope, refId, snippets } = req.body;

    const { data } = await axios.post(`${ANALYTICS_URL}/code-review/scan`, {
      snippets,
      useAi: true, // Python service decides whether to actually call an LLM based on its own configured key
    }, { timeout: 15000 });

    const report = await AiAnalysisReport.create({
      userId, projectId, scope, refId,
      bugDensityScore: data.bugDensityScore,
      complexityFlags: data.complexityFlags,
      refactorSuggestions: data.refactorSuggestions,
      summary: data.summary,
      generatedBy: data.generatedBy,
    });

    res.status(201).json(report);
  } catch (err) {
    console.error('[analytics.runCodeReview]', err.message);
    res.status(502).json({ error: 'Code review service unavailable' });
  }
}

module.exports = { getProductivityInsights, runCodeReview };
