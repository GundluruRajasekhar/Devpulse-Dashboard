const CommitLog = require('../models/mongo/CommitLog');
const User = require('../models/mysql/User');

// GET /api/leaderboard?teamId=1&days=14
// Combines MongoDB commit velocity with MySQL user identity, and anonymizes
// display names into "Developer A/B/C" ordering unless the requester is a manager/admin.
async function getLeaderboard(req, res) {
  try {
    const { days = 14 } = req.query;
    const since = new Date(Date.now() - Number(days) * 24 * 60 * 60 * 1000);

    const velocity = await CommitLog.aggregate([
      { $match: { authoredAt: { $gte: since } } },
      { $group: { _id: '$userId', commits: { $sum: 1 }, churn: { $sum: '$churnScore' } } },
      { $sort: { commits: -1 } },
    ]);

    const canSeeNames = req.user && ['manager', 'admin'].includes(req.user.role);
    let userMap = {};
    if (canSeeNames) {
      const ids = velocity.map(v => v._id);
      const users = await User.findAll({ where: { id: ids } });
      userMap = Object.fromEntries(users.map(u => [u.id, u.name]));
    }

    const leaderboard = velocity.map((v, idx) => ({
      rank: idx + 1,
      label: canSeeNames ? (userMap[v._id] || `User #${v._id}`) : `Developer ${String.fromCharCode(65 + idx)}`,
      commits: v.commits,
      churn: v.churn,
    }));

    res.json({ days: Number(days), anonymized: !canSeeNames, leaderboard });
  } catch (err) {
    console.error('[leaderboard.getLeaderboard]', err.message);
    res.status(500).json({ error: 'Failed to build leaderboard' });
  }
}

module.exports = { getLeaderboard };
