const DailyActivityEvent = require('../models/mongo/DailyActivityEvent');

// POST /api/focus/sessions — log a focus/distraction/break event from the client tracker
async function logEvent(req, res) {
  try {
    const event = await DailyActivityEvent.create(req.body);
    res.status(201).json(event);
  } catch (err) {
    console.error('[focus.logEvent]', err.message);
    res.status(500).json({ error: 'Failed to log activity event' });
  }
}

// GET /api/focus/summary?userId=2&days=7
async function getSummary(req, res) {
  try {
    const { userId, days = 7 } = req.query;
    const since = new Date(Date.now() - Number(days) * 24 * 60 * 60 * 1000);
    const match = { startTime: { $gte: since } };
    if (userId) match.userId = Number(userId);

    const rows = await DailyActivityEvent.aggregate([
      { $match: match },
      { $group: { _id: '$type', totalMinutes: { $sum: '$durationMinutes' }, count: { $sum: 1 } } },
    ]);

    const summary = { focus_session: { totalMinutes: 0, count: 0 }, distraction: { totalMinutes: 0, count: 0 }, break: { totalMinutes: 0, count: 0 } };
    rows.forEach(r => { summary[r._id] = { totalMinutes: r.totalMinutes, count: r.count }; });

    const focusScore = summary.focus_session.totalMinutes === 0
      ? 0
      : Math.round((summary.focus_session.totalMinutes / (summary.focus_session.totalMinutes + summary.distraction.totalMinutes + 1)) * 100);

    res.json({ days: Number(days), summary, focusScore });
  } catch (err) {
    console.error('[focus.getSummary]', err.message);
    res.status(500).json({ error: 'Failed to load focus summary' });
  }
}

module.exports = { logEvent, getSummary };
