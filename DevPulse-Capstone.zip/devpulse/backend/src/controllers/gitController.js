const CommitLog = require('../models/mongo/CommitLog');

// GET /api/git/activity?projectId=1&days=14
// Aggregates commit_logs into a daily commit-frequency + churn series for dashboard widgets.
async function getActivity(req, res) {
  try {
    const { projectId, days = 14 } = req.query;
    const since = new Date(Date.now() - Number(days) * 24 * 60 * 60 * 1000);
    const match = { authoredAt: { $gte: since } };
    if (projectId) match.projectId = Number(projectId);

    const series = await CommitLog.aggregate([
      { $match: match },
      {
        $group: {
          _id: { $dateToString: { format: '%Y-%m-%d', date: '$authoredAt' } },
          commits: { $sum: 1 },
          additions: { $sum: '$additions' },
          deletions: { $sum: '$deletions' },
          churn: { $sum: '$churnScore' },
        },
      },
      { $sort: { _id: 1 } },
    ]);

    res.json({ days: Number(days), series });
  } catch (err) {
    console.error('[git.getActivity]', err.message);
    res.status(500).json({ error: 'Failed to load git activity' });
  }
}

// POST /api/git/commits  — ingest a commit event (e.g. from a webhook or poller)
async function recordCommit(req, res) {
  try {
    const payload = req.body;
    payload.churnScore = (payload.additions || 0) + (payload.deletions || 0);
    const commit = await CommitLog.findOneAndUpdate(
      { sha: payload.sha },
      payload,
      { upsert: true, new: true, setDefaultsOnInsert: true }
    );
    res.status(201).json(commit);
  } catch (err) {
    console.error('[git.recordCommit]', err.message);
    res.status(500).json({ error: 'Failed to record commit' });
  }
}

module.exports = { getActivity, recordCommit };
