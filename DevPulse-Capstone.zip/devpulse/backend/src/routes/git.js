const express = require('express');
const router = express.Router();
const { requireAuth } = require('../middleware/auth');
const { getActivity, recordCommit } = require('../controllers/gitController');

router.get('/activity', requireAuth, getActivity);
router.post('/commits', requireAuth, recordCommit);

module.exports = router;
