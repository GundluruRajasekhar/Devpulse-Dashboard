const express = require('express');
const router = express.Router();
const { requireAuth } = require('../middleware/auth');
const { logEvent, getSummary } = require('../controllers/focusController');

router.post('/sessions', requireAuth, logEvent);
router.get('/summary', requireAuth, getSummary);

module.exports = router;
