const express = require('express');
const router = express.Router();
const { requireAuth } = require('../middleware/auth');
const { getProductivityInsights, runCodeReview } = require('../controllers/analyticsController');

router.get('/productivity', requireAuth, getProductivityInsights);
router.post('/code-review', requireAuth, runCodeReview);

module.exports = router;
