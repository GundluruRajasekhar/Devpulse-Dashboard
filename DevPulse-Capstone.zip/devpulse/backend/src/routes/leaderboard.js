const express = require('express');
const router = express.Router();
const { requireAuth } = require('../middleware/auth');
const { getLeaderboard } = require('../controllers/leaderboardController');

router.get('/', requireAuth, getLeaderboard);

module.exports = router;
