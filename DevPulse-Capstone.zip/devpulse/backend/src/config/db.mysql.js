// MySQL connection via Sequelize — owns Users, Teams, Projects, Access_Tokens
const { Sequelize } = require('sequelize');

const sequelize = new Sequelize(
  process.env.MYSQL_DATABASE || 'devpulse',
  process.env.MYSQL_USER || 'devpulse_user',
  process.env.MYSQL_PASSWORD || '',
  {
    host: process.env.MYSQL_HOST || 'localhost',
    port: process.env.MYSQL_PORT || 3306,
    dialect: 'mysql',
    logging: false,
    pool: { max: 10, min: 0, idle: 10000 },
  }
);

async function connectMySQL() {
  try {
    await sequelize.authenticate();
    console.log('[mysql] connected');
  } catch (err) {
    console.error('[mysql] connection failed — API will run in degraded mode:', err.message);
  }
}

module.exports = { sequelize, connectMySQL };
