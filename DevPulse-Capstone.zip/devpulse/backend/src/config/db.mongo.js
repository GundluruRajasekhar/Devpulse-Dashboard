// MongoDB connection via Mongoose — owns commit_logs, daily_activity_events, ai_analysis_reports
const mongoose = require('mongoose');

async function connectMongo() {
  try {
    await mongoose.connect(process.env.MONGO_URI || 'mongodb://localhost:27017/devpulse');
    console.log('[mongo] connected');
  } catch (err) {
    console.error('[mongo] connection failed — API will run in degraded mode:', err.message);
  }
}

module.exports = { connectMongo };
